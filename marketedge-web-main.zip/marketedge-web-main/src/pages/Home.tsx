import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h1>ABC</h1>
      <p>Welcome ABCCCC!</p>
    </div>
  );
};

export default Home;
