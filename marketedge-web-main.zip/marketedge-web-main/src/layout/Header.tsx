import React from 'react';
import { AppBar, Toolbar, Box, Typography } from '@mui/material';

import logo from '../assets/icons/assistant.svg';
import accountLogo from '../assets/icons/account.svg';
import dropdownIcon from '../assets/icons/ArrowDropDownFilled.svg';

const Header: React.FC = () => {
  return (
    <AppBar position="static" sx={{ backgroundColor: '#093C9ED4', height: '71px' }}>
      <Toolbar className="flex justify-between items-center w-full"
      sx={{ ml: 4, mr: 4, pl: '0 !important', pr: '0 !important' }}>
        <Box>
          <img src={logo} alt="Logo"/>
        </Box>
        <Box display="flex" alignItems="center" p={2}>
          <Box>
            <img src={accountLogo} alt="Account Logo" />
          </Box>
          <Typography sx={{ ml: 1 , fontSize: '16px', fontWeight: 400}}>Account</Typography>
          <Box sx={{ mr: 4 }}>
            <img src={dropdownIcon} alt="Another Icon"  />
          </Box>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
