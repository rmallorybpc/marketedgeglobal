import React, { useState } from 'react';
import { List, ListItemButton, ListItemText, ListItemIcon, Box } from '@mui/material';
import Drawer from '@mui/material/Drawer';
import { Link } from 'react-router-dom';

import Dashboard from '../assets/icons/Dashboard.svg';
import AiAgent from '../assets/icons/AiAgents.svg';
import File from '../assets/icons/Files.svg';
import Transcribe from '../assets/icons/Transcribe.svg';

type SidebarItemProps = {
  to: string;
  icon: string;
  label: string;
  activeItem: string | null;
  setActiveItem: (item: string) => void;
};

const SidebarItem: React.FC<SidebarItemProps> = ({ to, icon, label, activeItem, setActiveItem }) => {
  const handleClick = () => setActiveItem(label);

  return (
    <ListItemButton
      component={Link}
      to={to}
      sx={{
        justifyContent: 'center',
        width: '80px',
        height: '80px',
        mt: 1,
        '&:hover': {
          backgroundColor: '#D0E0F2',
          borderRadius: '8px',
        },
      }}
      onClick={handleClick}
    >
      <ListItemIcon>
        <Box
          sx={{
            width: '80px',
            height: '80px',
            textAlign: 'center',
            borderRadius: '8px',
            backgroundColor: activeItem === label ? '#D0E0F2' : 'transparent',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <img src={icon} alt="Icon" style={{ width: '24px', height: '24px' }} />
          <Box
            sx={{
              height: '22.4px',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <ListItemText
              primary={label}
              primaryTypographyProps={{
                sx: {
                  fontSize: '14px',
                  fontWeight: 600,
                  lineHeight: '16px',
                },
              }}
            />
          </Box>
        </Box>
      </ListItemIcon>
    </ListItemButton>
  );
};

const Sidebar: React.FC = () => {
  const [activeItem, setActiveItem] = useState<string | null>(null);

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: '112px',
        '& .MuiDrawer-paper': {
          width: '112px',
          marginTop: '71px',
          backgroundColor: '#eff2f7',
          color: '#484848',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        },
      }}
    >
      <List
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Box sx={{ height: '8px' }} /> {/* Placeholder height */}

        <SidebarItem
          to="/"
          icon={Dashboard}
          label="Dashboard"
          activeItem={activeItem}
          setActiveItem={setActiveItem}
        />
        <SidebarItem
          to="/p1"
          icon={Transcribe}
          label="Transcribe"
          activeItem={activeItem}
          setActiveItem={setActiveItem}
        />
        <SidebarItem
          to="/p1"
          icon={AiAgent}
          label="AI Agents"
          activeItem={activeItem}
          setActiveItem={setActiveItem}
        />
        <SidebarItem
          to="/p1"
          icon={File}
          label="Files"
          activeItem={activeItem}
          setActiveItem={setActiveItem}
        />
      </List>
    </Drawer>
  );
};

export default Sidebar;